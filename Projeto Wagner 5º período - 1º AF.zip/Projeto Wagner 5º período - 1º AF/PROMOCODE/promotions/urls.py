from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('promotions/', views.promotions_list, name='promotions-list'), 
    path('promotions/<int:pk>/', views.promotion_detail, name='promotion-detail'),
    path('sobre/', views.sobre, name='sobre'),
]
