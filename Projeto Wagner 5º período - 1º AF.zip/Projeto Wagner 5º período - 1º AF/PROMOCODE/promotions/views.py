from django.shortcuts import render

# Create your views here.

def home(request):
    return render(request, 'home.html')

#-----------------------------------------------------------------------------------------#

promotions = [
    {   
        'id': 1,
        'title': 'Gabinete Gamer NZXT H9 Flow',
        'price': 979.90,
        'url': 'https://www.kabum.com.br/produto/418218/gabinete-gamer-nzxt-h9-flow-mid-tower-atx-lateral-e-frontal-em-vidro-branco-cm-h91fw-01?utm_id=21416437422&gad_source=1&gclid=CjwKCAjwodC2BhAHEiwAE67hJPBgLBSvcEp7WJfff9fLS9aIMW5Euk5nCl2NrhjM8wDMvPyYswP9ThoCQ24QAvD_BwE'
    },
    {
        'id': 2,
        'title': 'Iphone 15 Pro Max',
        'price': 7.999,
        'url': 'https://www.amazon.com.br/Apple-iPhone-Pro-Max-256/dp/B0CHX7PHJT/ref=asc_df_B0CHX7PHJT/?tag=googleshopp00-20&linkCode=df0&hvadid=709964503151&hvpos=&hvnetw=g&hvrand=14968059733118877756&hvpone=&hvptwo=&hvqmt=&hvdev=c&hvdvcmdl=&hvlocint=&hvlocphy=9196895&hvtargid=pla-2218620892934&mcid=66b7bee07ddc3769bc60ee3d5386c291&gad_source=1&th=1'
    },
    {
        'id': 3,
        'title': 'Tablet Samsung',
        'price': 4.743,
        'url': 'https://www.amazon.com.br/Tablet-Samsung-Galaxy-256GB-Imersiva/dp/B0CCSYG7WM/ref=asc_df_B0CCSYG7WM/?tag=googleshopp00-20&linkCode=df0&hvadid=709884378406&hvpos=&hvnetw=g&hvrand=13629425658617356729&hvpone=&hvptwo=&hvqmt=&hvdev=c&hvdvcmdl=&hvlocint=&hvlocphy=9196895&hvtargid=pla-2199233886662&mcid=bc4d822a1dcc3ebc9d95283f40bc4138&gad_source=1&th=1'
    },
]

def promotions_list(request):
    context = {
        'promotions': promotions,
    }
    return render (request, 'promotions/list.html', context)
 
def promotion_detail(request, pk):
    promotion = promotions[pk-1]
    context = {
        'promotion': promotion,
    }
    return render(request, 'promotions/detail.html', context)

#-----------------------------------------------------------------------------------------#

def sobre(request):
    return render(request, 'promotions/sobre.html')